﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestTCP1.Lib;

namespace TestTCP1.Forms
{
    public partial class ConfigForm : UserControl
    {
        private TCPConn tcp = TCPConn.newInstance();
        public ConfigForm()
        {
            InitializeComponent();
            button15.Text = tcp.IsRunning() ? "Disconnect" : "Connect";
            ipBox.Enabled = !tcp.IsRunning();
            portBox.Enabled = !tcp.IsRunning();
            statusLabel.Text = "Status: " + (tcp.IsRunning() ? "Connected" : "Disconnected");
        }

        private async void button15_Click(object sender, EventArgs e)
        {
            if (tcp.IsRunning())
            {
                tcp.StopConnection();
                ipBox.Enabled = true;
                portBox.Enabled = true;
                button15.Invoke(new Action(() => { button15.Text = "Connect"; }));
            }
            else
            {
                Properties.Settings.Default["ServerIpAddress"] = ipBox.Text;
                Properties.Settings.Default["ServerPort"] = int.Parse(portBox.Text);
                Properties.Settings.Default.Save();
                tcp.SetIpAddress(ipBox.Text);
                tcp.SetPort(int.Parse(portBox.Text));
                this.Invoke(new Action(() =>
                {
                    button15.Text = "Disconnect";
                    ipBox.Enabled = false;
                    portBox.Enabled = false;
                }));
                await tcp.StartConnection();
                MessageBox.Show("Save Complete");
            }
            statusLabel.Invoke(new Action(() =>
            {
                statusLabel.Text = "Status: " + (tcp.IsRunning() ? "Connected" : "Disconnected");
            }));
        }

        private void ConfigForm_Load(object sender, EventArgs e)
        {

            ipBox.Text = Properties.Settings.Default["ServerIpAddress"].ToString();
            portBox.Text = Properties.Settings.Default["ServerPort"].ToString();
        }
    }
}
