﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestTCP1.Lib;
using TestTCP1.Model;

namespace TestTCP1.Forms
{
    public partial class DashboardControl : UserControl
    {
        public string Model { get; private set; } = string.Empty;
        private readonly FileLib fileLib = new FileLib();
        private readonly DbConn dbCon = new DbConn();
        private readonly TCPConn mainConn = TCPConn.newInstance();
        private readonly TCPConn? livePositionConn = null;
        private List<PositionModel> Positions = new List<PositionModel>();
        private List<InspectionView> InspectionViews = new List<InspectionView>();
        private int? CamPoint = null;
        private readonly Mapper mapper = AutoMapConfig.GetMapper();
        private string oldScanCode = string.Empty;
        private DateTime startTime = DateTime.Now;
        public DashboardControl()
        {
            InitializeComponent();
            textBox1.Enabled = false;
            finalJudgeLabel.Text = string.Empty;
        }
        protected override void OnControlRemoved(ControlEventArgs e)
        {
            mainConn.StopConnection();
            livePositionConn?.StopConnection();
            base.OnControlRemoved(e);
        }
        public DashboardControl(string _Model)
        {
            InitializeComponent();

            finalJudgeLabel.Text = string.Empty;

            livePositionConn = TCPConn.newInstance();
            livePositionConn.setLog(false);
            Model = _Model;
            runningModel.Text = Model;
            DataTable dt = new DataTable();
            dt.Columns.Add("Area");
            dt.Columns.Add("Judgement");
            inspectionListGridView.DataSource = dt;
        }
        private async Task GetPos()
        {
            bool checkIfJudgementEmpty= InspectionViews.Any(x => x.Judgement == string.Empty);
            if (!checkIfJudgementEmpty)
            {
                for (int i=0;i<Positions.Count;i++)
                {
                    RecordInspectionModel record = mapper.Map<RecordInspectionModel>(Positions[i]);
                    record.ScanCode = oldScanCode;
                    record.Judgement = InspectionViews[i].Judgement;
                    await dbCon.SavePosRecord(record);
                }
            }
            Positions = await dbCon.GetPositionByModel(Model);
            InspectionViews = mapper.Map<List<InspectionView>>(Positions);
            CamPoint = await dbCon.GetCamPoint(Model);
            this.inspectionListGridView.Invoke(new Action(() =>
            {
                inspectionListGridView.DataSource = InspectionViews;
                inspectionListGridView.Refresh();
                inspectionListGridView.Columns[2].Visible = false;
            }));
            campointLabel.Invoke(new Action(() => campointLabel.Text = CamPoint?.ToString() ?? "-"));
        }
        private async Task TriggerCamPoint()
        {
            await mainConn.SendCommand($"WR W0F8 {CamPoint}");
            await mainConn.SendCommand($"WR MR401 1");
            Thread.Sleep(10);
            await mainConn.SendCommand($"WR MR401 0");
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void SwitchControlState(string status)
        {
            switch (status)
            {
                case "waiting":
                    pictureBox1.Invoke(new Action(() => pictureBox1.Image = null));
                    scanLabel.Invoke(new Action(() => scanLabel.Text = textBox1.Text));
                    textBox1.Invoke(new Action(() => textBox1.Enabled = false));
                    statusLabel.Invoke(new Action(() => statusLabel.Text = "Waiting for start button (In-Progress)"));
                    break;
                case "running":
                    statusLabel.Invoke(new Action(() =>
                    {
                        statusLabel.Text = "Running...";
                    }));
                    break;
                case "complete":
                    oldScanCode = textBox1.Text;
                    scanLabel.Invoke(new Action(() => scanLabel.Text = string.Empty));
                    textBox1.Invoke(new Action(() => { textBox1.Enabled = true; textBox1.Text = string.Empty; })); ;
                    statusLabel.Invoke(new Action(() => statusLabel.Text = "Running Process Complete"));
                    break;
            }
        }
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter)
                return;
            finalJudgeLabel.Text = string.Empty;
            areaLabel.Text = string.Empty;
            decisionLabel.Text = string.Empty;
            processTimeLabel.Invoke(new Action(() => processTimeLabel.Text = "Process Time: 00:00:00"));
            startTime = DateTime.Now;
            processTimer.Enabled = true;
            processTimer.Start();
            Task.Run(ScanRun);
        }
        private async Task ScanRun()
        {
            await GetPos();
            SwitchControlState("waiting");
            string res = string.Empty;
            await mainConn.SendCommand("WR MR002 1");
            await mainConn.SendCommand("WR MR004 1");
            do
            {
                res = await mainConn.SendCommand($"RD MR8000");
            }
            while (!res.Contains("1") && !res.Contains("ok"));

            SwitchControlState("running");
            for (int i = 0; i < Positions.Count; i++)
            {
                var _pos = Positions[i];
                await StartProcess(_pos);
                var isPassed = await Trigger(_pos.CameraCheckpoint);
                InspectionViews[i].Judgement = isPassed ? "PASS" : "NG";

                InspectionViews[i].Image = isPassed ? await dbCon.GetLocalImage(_pos) : GetTriggerImgPath();
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                Task.Run(() => LoadImage(Positions[i], isPassed));
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                RecordInspectionModel record = mapper.Map<RecordInspectionModel>(_pos);
                record.ScanCode = textBox1.Text;
                record.Judgement = InspectionViews[i].Judgement;
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                Task.Run(new Action(() =>
                {
                    this.inspectionListGridView.Invoke(new Action(() =>
                    {
                        inspectionListGridView.DataSource = InspectionViews;
                        inspectionListGridView.Refresh();
                    }));

                    this.areaLabel.Invoke(new Action(() => areaLabel.Text = _pos.AreaInspection));
                    this.decisionLabel.Invoke(new Action(() =>
                    {
                        decisionLabel.Text = record.Judgement;
                        decisionLabel.ForeColor = isPassed ? Color.Lime : Color.DarkRed;
                    }));
                }));
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
            }
            finalJudgeLabel.Invoke(new Action(() =>
            {
                bool finalJudge = InspectionViews.Select(x => x.Judgement).Any(x => x.Contains("NG"));
                finalJudgeLabel.ForeColor = finalJudge ? Color.DarkRed : Color.Lime;
                finalJudgeLabel.Text = finalJudge ? "FAIL" : "PASS";
            }));
            string res1, res2;
            do
            {
                await StartProcess(new PositionModel() { X = 0, Y = 0, Z = 0, CameraCheckpoint = "" });
                res1 = await mainConn.SendCommand("WR MR8000 0");
                res2 = await mainConn.SendCommand("WR DM0 0");
            }
            while (!(res1.ToLower().Contains("ok") || res1.ToLower().Contains("1")) || !(res2.ToLower().Contains("ok") || res2.ToLower().Contains("1")));
            SwitchControlState("complete");
            processTimer.Stop();
            processTimer.Enabled = false;
        }
        private async Task LoadImage(PositionModel position, bool isPassed)
        {
            Thread.Sleep(5);
            string imgPath = isPassed ? await dbCon.GetLocalImage(position) : GetTriggerImgPath();
            //                string imgPath = isPassed ? await dbCon.GetLocalImage(Positions[i]) : GetTriggerImgPath();
            pictureBox1.Invoke(new Action(() =>
            {
                pictureBox1.Image = fileLib.ReadImage(imgPath, isPassed);//isPassed ? fileLib.ReadImage(imgPath) : Image.FromFile(imgPath);
            }));
        }
        private string GetTriggerImgPath()
        {
            Thread.Sleep(5);
            string foldername = $"{DateTime.Now.ToString("yyMMdd")}";
            string[] folders = fileLib.GetFolders(foldername);
            if (folders.Length < 1)
            {
                MessageBox.Show($"No Folder with prefix {foldername} Found", "Error");
                return string.Empty;
            }
            string latestDir = Path.Combine(folders[0], "CAM1");
            string[] img = fileLib.GetFiles(latestDir);
            return img.Length < 1 ? "" : img[0];
        }

        private async Task StartProcess(PositionModel data)
        {
            if (!mainConn.IsRunning())
                await mainConn.StartConnection();
            var s = await mainConn.SendCommand("WR MR300 0");
            string res = string.Empty;
            string xVal = String.Format("{0:0}", data.X * 1600 / 20);
            string yVal = String.Format("{0:0}", data.Y * 1600 / 20);
            string zVal = String.Format("{0:0}", data.Z * 1600 / 20);
            res = await mainConn.SendCommand($"WR CM8010 {xVal}");
            res = await mainConn.SendCommand($"WR CM8210 {yVal}");
            res = await mainConn.SendCommand($"WR CM8410 {zVal}");
            if (data.CameraCheckpoint != "")
                res = await mainConn.SendCommand($"WR W0F2 {data.CameraCheckpoint}");
            if (data.X==0 && data.Y==0 && data.Z==0)
            {
                await mainConn.SendCommand("WR MR002 0");
                await mainConn.SendCommand("WR MR004 0");
            }
            s = await mainConn.SendCommand("WR MR300 1");
            bool[] confirms = new bool[3];
            do
            {
                confirms[0] = (await mainConn.SendCommand($"RD CR8401")).Contains("1");
                confirms[1] = (await mainConn.SendCommand($"RD CR8501")).Contains("1");
                confirms[2] = (await mainConn.SendCommand($"RD CR8601")).Contains("1");
            }
            while (confirms.Any(x => x == false));
            string test = string.Empty;
        }
        private async Task<bool> Trigger(string checkPoint)
        {
            //res = await conn.SendCommand("WR MR400 1");
            //Thread.Sleep(10);
            //res = await conn.SendCommand("WR MR400 0");
            bool? result = null;
            string res = string.Empty;
            do
            {
                res = await mainConn.SendCommand("RD MR400");
            }
            while (!res.Contains("1"));
            do
            {
                res = await mainConn.SendCommand("RD MR1000");
                if (res.Contains("1"))
                    result = true;
                res = await mainConn.SendCommand("RD MR1001");
                if (res.Contains("1"))
                    result = false;
            }
            while (result is null);
            //this.Invoke(new Action(() =>
            //MessageBox.Show("Incorrect trigger output")));
            await mainConn.SendCommand("WR MR400 0");
            return result.Value;
        }

        private async void DashboardControl_Load(object sender, EventArgs e)
        {
            if (Model == null || Model == string.Empty)
                return;
            if (!mainConn.IsRunning())
                await mainConn.StartConnection();
            if (livePositionConn is not null && !livePositionConn.IsRunning())
                await livePositionConn.StartConnection();
            await GetPos();

            if (CamPoint is not null)
                await TriggerCamPoint();
        }
        private void checkPhoto()
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Task.Run(new Action(async () =>
            {
                timeLabel.Invoke(new Action(() =>
                {
                    timeLabel.Text = $"Date: {DateTime.Now.ToString("dd MMM yyyy")}\nTime: {DateTime.Now.ToString("HH:mm:ss")}";
                }));

                string res = string.Empty;
                decimal val = 0;
                if (livePositionConn is null)
                    return;
                if (!livePositionConn.IsRunning())
                    await livePositionConn.StartConnection();
                res = await livePositionConn.SendCommand("RD CM8830");
                if (!decimal.TryParse(res, out val))
                    val = 0;
                xLabel.Invoke(new Action(() =>
                xLabel.Text = $"X: {(val / 1600 * 20).ToString("0.00")} mm"));
                //Thread.Sleep(5);
                res = await livePositionConn.SendCommand("RD CM8870");
                if (!decimal.TryParse(res, out val))
                    val = 0;
                yLabel.Invoke(new Action(() =>
                yLabel.Text = $"Y: {(val / 1600 * 20).ToString("0.00")} mm"));
                //Thread.Sleep(5);
                res = await livePositionConn.SendCommand("RD CM8910");
                if (!decimal.TryParse(res, out val))
                    val = 0;
                zLabel.Invoke(new Action(() =>
                zLabel.Text = $"Z: {(val / 1600 * 20).ToString("0.00")} mm"));
            }));
        }

        private void timeLabel_Click(object sender, EventArgs e)
        {

        }

        private void scanLabel_Click(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void labeld_Click(object sender, EventArgs e)
        {
        }

        private void areaLabel_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {
        }

        private void inspectionListGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {
        }

        private void label6_Click(object sender, EventArgs e)
        {
        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {
        }

        private void statusLabel_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void zLabel_Click(object sender, EventArgs e)
        {
        }

        private void yLabel_Click(object sender, EventArgs e)
        {
        }

        private void xLabel_Click(object sender, EventArgs e)
        {
        }

        private void runningModel_Click(object sender, EventArgs e)
        {
        }

        private void processTimer_Tick(object sender, EventArgs e)
        {
            var elapsed = DateTime.Now - startTime;
            processTimeLabel.Invoke(new Action(() =>
            {
                processTimeLabel.Text = $"Process Time: {elapsed.Hours.ToString("00")}:{elapsed.Minutes.ToString("00")}:{elapsed.Seconds.ToString("00")}";
            }));
        }

        private async void inspectionListGridView_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            var pos = Positions[index];
            var ins = inspectionListGridView.Rows[index].Cells[1];
            var frm = new ProcessVerificationModalForm(pos, ins.Value.ToString() == "PASS", InspectionViews[index].Image);
            frm.WindowState = FormWindowState.Maximized;
            var res = frm.ShowDialog();
            if (res == DialogResult.OK)
            {
                InspectionViews[index].Judgement = frm.resultVerification ? "PASS" : "NG";
                //RecordInspectionModel record = mapper.Map<RecordInspectionModel>(pos);
                //record.Judgement = InspectionViews[index].Judgement;
                if (frm.resultVerification)
                {
                    await dbCon.SaveImage(pos.Model, pos.Pos, frm._image);
                    fileLib.SaveImage(frm._imageFull, frm._image);
                }
                await Task.Run(new Action(() =>
                {
                    this.inspectionListGridView.Invoke(new Action(() =>
                    {
                        inspectionListGridView.DataSource = InspectionViews;
                        inspectionListGridView.Refresh();
                    }));
                    finalJudgeLabel.Invoke(new Action(() =>
                    {
                        bool finalJudge = InspectionViews.Select(x => x.Judgement).Any(x => x.Contains("NG"));
                        finalJudgeLabel.ForeColor = finalJudge ? Color.DarkRed : Color.Lime;
                        finalJudgeLabel.Text = finalJudge ? "FAIL" : "PASS";
                    }));
                }));
            }
        }
    }
}
