﻿namespace TestTCP1.Forms
{
    partial class DashboardControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            runningModel = new Label();
            groupBox1 = new GroupBox();
            label3 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            panel6 = new Panel();
            panel3 = new Panel();
            scanLabel = new Label();
            groupBox2 = new GroupBox();
            panel7 = new Panel();
            labeld = new Label();
            panel5 = new Panel();
            decisionLabel = new Label();
            panel2 = new Panel();
            panel4 = new Panel();
            areaLabel = new Label();
            label4 = new Label();
            groupBox3 = new GroupBox();
            inspectionListGridView = new DataGridView();
            groupBox4 = new GroupBox();
            label6 = new Label();
            groupBox5 = new GroupBox();
            statusLabel = new Label();
            pictureBox1 = new PictureBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            zLabel = new Label();
            yLabel = new Label();
            xLabel = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            finalJudgeLabel = new Label();
            processTimeLabel = new Label();
            processTimer = new System.Windows.Forms.Timer(components);
            timeLabel = new Label();
            groupBox6 = new GroupBox();
            panel1 = new Panel();
            label1 = new Label();
            groupBox7 = new GroupBox();
            campointLabel = new Label();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            groupBox1.SuspendLayout();
            panel6.SuspendLayout();
            panel3.SuspendLayout();
            groupBox2.SuspendLayout();
            panel7.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)inspectionListGridView).BeginInit();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            groupBox6.SuspendLayout();
            panel1.SuspendLayout();
            groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // runningModel
            // 
            runningModel.BackColor = Color.MediumTurquoise;
            runningModel.Dock = DockStyle.Fill;
            runningModel.Font = new Font("Segoe UI", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            runningModel.Location = new Point(3, 25);
            runningModel.Name = "runningModel";
            runningModel.Size = new Size(255, 48);
            runningModel.TabIndex = 0;
            runningModel.Text = "-";
            runningModel.TextAlign = ContentAlignment.MiddleCenter;
            runningModel.Click += runningModel_Click;
            // 
            // groupBox1
            // 
            groupBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            groupBox1.BackColor = SystemColors.Control;
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(panel6);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(790, 250);
            groupBox1.Margin = new Padding(3, 2, 3, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 2, 3, 2);
            groupBox1.Size = new Size(261, 149);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Serial No.";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.MediumTurquoise;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(69, 89);
            label3.Name = "label3";
            label3.Size = new Size(124, 21);
            label3.TabIndex = 2;
            label3.Text = "RUNNING S/N:";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.MediumTurquoise;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(89, 35);
            label2.Name = "label2";
            label2.Size = new Size(89, 21);
            label2.TabIndex = 1;
            label2.Text = "Scan Code";
            label2.Click += label2_Click;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.White;
            textBox1.Location = new Point(6, 58);
            textBox1.Margin = new Padding(3, 2, 3, 2);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(249, 29);
            textBox1.TabIndex = 0;
            textBox1.TextAlign = HorizontalAlignment.Center;
            textBox1.TextChanged += textBox1_TextChanged;
            textBox1.KeyDown += textBox1_KeyDown;
            // 
            // panel6
            // 
            panel6.BackColor = Color.MediumTurquoise;
            panel6.Controls.Add(panel3);
            panel6.Dock = DockStyle.Fill;
            panel6.Location = new Point(3, 24);
            panel6.Name = "panel6";
            panel6.Size = new Size(255, 123);
            panel6.TabIndex = 5;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Transparent;
            panel3.Controls.Add(scanLabel);
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(0, 97);
            panel3.Name = "panel3";
            panel3.Size = new Size(255, 26);
            panel3.TabIndex = 4;
            // 
            // scanLabel
            // 
            scanLabel.BackColor = Color.Transparent;
            scanLabel.Dock = DockStyle.Fill;
            scanLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            scanLabel.ForeColor = SystemColors.Highlight;
            scanLabel.Location = new Point(0, 0);
            scanLabel.Name = "scanLabel";
            scanLabel.Size = new Size(255, 26);
            scanLabel.TabIndex = 3;
            scanLabel.Text = "-";
            scanLabel.TextAlign = ContentAlignment.TopCenter;
            scanLabel.Click += scanLabel_Click;
            // 
            // groupBox2
            // 
            groupBox2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            groupBox2.BackColor = SystemColors.Control;
            groupBox2.Controls.Add(panel7);
            groupBox2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox2.Location = new Point(790, 403);
            groupBox2.Margin = new Padding(3, 2, 3, 2);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 2, 3, 2);
            groupBox2.Size = new Size(261, 137);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "Inspection";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // panel7
            // 
            panel7.BackColor = Color.MediumTurquoise;
            panel7.Controls.Add(labeld);
            panel7.Controls.Add(panel5);
            panel7.Controls.Add(panel4);
            panel7.Controls.Add(label4);
            panel7.Dock = DockStyle.Fill;
            panel7.Location = new Point(3, 24);
            panel7.Name = "panel7";
            panel7.Size = new Size(255, 111);
            panel7.TabIndex = 20;
            // 
            // labeld
            // 
            labeld.AutoSize = true;
            labeld.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            labeld.Location = new Point(86, 53);
            labeld.Name = "labeld";
            labeld.Size = new Size(80, 21);
            labeld.TabIndex = 6;
            labeld.Text = "Decision:";
            labeld.Click += labeld_Click;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Transparent;
            panel5.Controls.Add(decisionLabel);
            panel5.Controls.Add(panel2);
            panel5.Location = new Point(3, 77);
            panel5.Name = "panel5";
            panel5.Size = new Size(249, 31);
            panel5.TabIndex = 9;
            // 
            // decisionLabel
            // 
            decisionLabel.BackColor = Color.MediumTurquoise;
            decisionLabel.Dock = DockStyle.Fill;
            decisionLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            decisionLabel.ForeColor = Color.Lime;
            decisionLabel.Location = new Point(0, 0);
            decisionLabel.Name = "decisionLabel";
            decisionLabel.Size = new Size(249, 31);
            decisionLabel.TabIndex = 7;
            decisionLabel.TextAlign = ContentAlignment.TopCenter;
            decisionLabel.Click += label5_Click;
            // 
            // panel2
            // 
            panel2.Location = new Point(6, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(252, 31);
            panel2.TabIndex = 17;
            // 
            // panel4
            // 
            panel4.Controls.Add(areaLabel);
            panel4.Location = new Point(3, 28);
            panel4.Name = "panel4";
            panel4.Size = new Size(249, 17);
            panel4.TabIndex = 8;
            // 
            // areaLabel
            // 
            areaLabel.BackColor = Color.MediumTurquoise;
            areaLabel.Dock = DockStyle.Fill;
            areaLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            areaLabel.Location = new Point(0, 0);
            areaLabel.Name = "areaLabel";
            areaLabel.Size = new Size(249, 17);
            areaLabel.TabIndex = 5;
            areaLabel.TextAlign = ContentAlignment.MiddleCenter;
            areaLabel.Click += areaLabel_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(82, 3);
            label4.Name = "label4";
            label4.Size = new Size(101, 21);
            label4.TabIndex = 4;
            label4.Text = "Checkpoint:";
            label4.Click += label4_Click;
            // 
            // groupBox3
            // 
            groupBox3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            groupBox3.Controls.Add(inspectionListGridView);
            groupBox3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox3.Location = new Point(1057, 97);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(3, 2, 3, 2);
            groupBox3.Size = new Size(307, 476);
            groupBox3.TabIndex = 4;
            groupBox3.TabStop = false;
            groupBox3.Text = "Inspection List:";
            groupBox3.Enter += groupBox3_Enter;
            // 
            // inspectionListGridView
            // 
            inspectionListGridView.AllowUserToAddRows = false;
            inspectionListGridView.AllowUserToDeleteRows = false;
            inspectionListGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            inspectionListGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            inspectionListGridView.BackgroundColor = SystemColors.Control;
            inspectionListGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            inspectionListGridView.Dock = DockStyle.Fill;
            inspectionListGridView.Location = new Point(3, 24);
            inspectionListGridView.Margin = new Padding(3, 2, 3, 2);
            inspectionListGridView.Name = "inspectionListGridView";
            inspectionListGridView.ReadOnly = true;
            inspectionListGridView.RowHeadersWidth = 51;
            inspectionListGridView.RowTemplate.Height = 29;
            inspectionListGridView.Size = new Size(301, 450);
            inspectionListGridView.TabIndex = 0;
            inspectionListGridView.CellContentClick += inspectionListGridView_CellContentClick;
            inspectionListGridView.CellContentDoubleClick += inspectionListGridView_CellContentDoubleClick;
            // 
            // groupBox4
            // 
            groupBox4.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            groupBox4.Controls.Add(label6);
            groupBox4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox4.Location = new Point(866, 577);
            groupBox4.Margin = new Padding(3, 2, 3, 2);
            groupBox4.Name = "groupBox4";
            groupBox4.Padding = new Padding(3, 2, 3, 2);
            groupBox4.Size = new Size(256, 66);
            groupBox4.TabIndex = 5;
            groupBox4.TabStop = false;
            groupBox4.Text = "Log File:";
            groupBox4.Enter += groupBox4_Enter;
            // 
            // label6
            // 
            label6.BackColor = Color.LightGreen;
            label6.Dock = DockStyle.Fill;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label6.Location = new Point(3, 24);
            label6.Name = "label6";
            label6.Size = new Size(250, 40);
            label6.TabIndex = 8;
            label6.Text = "log1123445.txt";
            label6.TextAlign = ContentAlignment.MiddleLeft;
            label6.Click += label6_Click;
            // 
            // groupBox5
            // 
            groupBox5.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            groupBox5.Controls.Add(statusLabel);
            groupBox5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox5.Location = new Point(14, 577);
            groupBox5.Margin = new Padding(3, 2, 3, 2);
            groupBox5.Name = "groupBox5";
            groupBox5.Padding = new Padding(3, 2, 3, 2);
            groupBox5.Size = new Size(834, 66);
            groupBox5.TabIndex = 9;
            groupBox5.TabStop = false;
            groupBox5.Text = "Status:";
            groupBox5.Enter += groupBox5_Enter;
            // 
            // statusLabel
            // 
            statusLabel.BackColor = Color.LightGreen;
            statusLabel.Dock = DockStyle.Fill;
            statusLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            statusLabel.Location = new Point(3, 24);
            statusLabel.Name = "statusLabel";
            statusLabel.Size = new Size(828, 40);
            statusLabel.TabIndex = 8;
            statusLabel.Text = "log1123445.txt";
            statusLabel.TextAlign = ContentAlignment.MiddleLeft;
            statusLabel.Click += statusLabel_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Location = new Point(11, 121);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(776, 452);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.Controls.Add(zLabel, 2, 0);
            tableLayoutPanel1.Controls.Add(yLabel, 1, 0);
            tableLayoutPanel1.Controls.Add(xLabel, 0, 0);
            tableLayoutPanel1.Location = new Point(11, 97);
            tableLayoutPanel1.Margin = new Padding(3, 2, 3, 2);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(776, 20);
            tableLayoutPanel1.TabIndex = 11;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // zLabel
            // 
            zLabel.AutoSize = true;
            zLabel.Dock = DockStyle.Fill;
            zLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            zLabel.Location = new Point(519, 0);
            zLabel.Name = "zLabel";
            zLabel.Size = new Size(254, 20);
            zLabel.TabIndex = 2;
            zLabel.Text = "Z: 0.00 mm";
            zLabel.TextAlign = ContentAlignment.MiddleCenter;
            zLabel.Click += zLabel_Click;
            // 
            // yLabel
            // 
            yLabel.AutoSize = true;
            yLabel.Dock = DockStyle.Fill;
            yLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            yLabel.Location = new Point(261, 0);
            yLabel.Name = "yLabel";
            yLabel.Size = new Size(252, 20);
            yLabel.TabIndex = 1;
            yLabel.Text = "Y: 0.00 mm";
            yLabel.TextAlign = ContentAlignment.MiddleCenter;
            yLabel.Click += yLabel_Click;
            // 
            // xLabel
            // 
            xLabel.AutoSize = true;
            xLabel.Dock = DockStyle.Fill;
            xLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            xLabel.Location = new Point(3, 0);
            xLabel.Name = "xLabel";
            xLabel.Size = new Size(252, 20);
            xLabel.TabIndex = 0;
            xLabel.Text = "X: 0.00 mm";
            xLabel.TextAlign = ContentAlignment.MiddleCenter;
            xLabel.Click += xLabel_Click;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // finalJudgeLabel
            // 
            finalJudgeLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            finalJudgeLabel.AutoSize = true;
            finalJudgeLabel.Font = new Font("Segoe UI", 48F, FontStyle.Bold, GraphicsUnit.Point);
            finalJudgeLabel.Location = new Point(1107, 4);
            finalJudgeLabel.Name = "finalJudgeLabel";
            finalJudgeLabel.Size = new Size(189, 86);
            finalJudgeLabel.TabIndex = 12;
            finalJudgeLabel.Text = "PASS";
            // 
            // processTimeLabel
            // 
            processTimeLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            processTimeLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            processTimeLabel.Location = new Point(796, 542);
            processTimeLabel.Name = "processTimeLabel";
            processTimeLabel.Size = new Size(252, 31);
            processTimeLabel.TabIndex = 13;
            processTimeLabel.Text = "Process Time: 00:00:00";
            processTimeLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // processTimer
            // 
            processTimer.Interval = 1000;
            processTimer.Tick += processTimer_Tick;
            // 
            // timeLabel
            // 
            timeLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            timeLabel.AutoSize = true;
            timeLabel.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            timeLabel.Location = new Point(1128, 586);
            timeLabel.Name = "timeLabel";
            timeLabel.Size = new Size(57, 50);
            timeLabel.TabIndex = 14;
            timeLabel.Text = "Date:\r\nTime:";
            timeLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // groupBox6
            // 
            groupBox6.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            groupBox6.BackColor = SystemColors.Control;
            groupBox6.Controls.Add(runningModel);
            groupBox6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox6.Location = new Point(790, 97);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(261, 76);
            groupBox6.TabIndex = 15;
            groupBox6.TabStop = false;
            groupBox6.Text = "Model";
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.Controls.Add(label1);
            panel1.Location = new Point(154, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(932, 85);
            panel1.TabIndex = 16;
            // 
            // label1
            // 
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Segoe UI", 48F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Size = new Size(932, 85);
            label1.TabIndex = 2;
            label1.Text = "AUTO INSPECTION MACHINE";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // groupBox7
            // 
            groupBox7.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            groupBox7.BackColor = SystemColors.Control;
            groupBox7.Controls.Add(campointLabel);
            groupBox7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox7.Location = new Point(790, 179);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new Size(261, 66);
            groupBox7.TabIndex = 16;
            groupBox7.TabStop = false;
            groupBox7.Text = "Camera";
            // 
            // campointLabel
            // 
            campointLabel.BackColor = Color.MediumTurquoise;
            campointLabel.Dock = DockStyle.Fill;
            campointLabel.Font = new Font("Segoe UI", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            campointLabel.Location = new Point(3, 25);
            campointLabel.Name = "campointLabel";
            campointLabel.Size = new Size(255, 38);
            campointLabel.TabIndex = 0;
            campointLabel.Text = "-";
            campointLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            pictureBox2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox2.Image = Properties.Resources.dharma;
            pictureBox2.Location = new Point(1302, 6);
            pictureBox2.Margin = new Padding(3, 2, 3, 2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(78, 85);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 18;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.flex;
            pictureBox3.Location = new Point(11, 5);
            pictureBox3.Margin = new Padding(3, 2, 3, 2);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(137, 85);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 19;
            pictureBox3.TabStop = false;
            // 
            // DashboardControl
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            Controls.Add(processTimeLabel);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(groupBox7);
            Controls.Add(groupBox6);
            Controls.Add(timeLabel);
            Controls.Add(finalJudgeLabel);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox5);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(panel1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "DashboardControl";
            Size = new Size(1386, 645);
            Load += DashboardControl_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            panel6.ResumeLayout(false);
            panel3.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel5.ResumeLayout(false);
            panel4.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)inspectionListGridView).EndInit();
            groupBox4.ResumeLayout(false);
            groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            groupBox6.ResumeLayout(false);
            panel1.ResumeLayout(false);
            groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label runningModel;
        private GroupBox groupBox1;
        private Label scanLabel;
        private Label label3;
        private Label label2;
        private TextBox textBox1;
        private GroupBox groupBox2;
        private Label decisionLabel;
        private Label labeld;
        private Label label4;
        private GroupBox groupBox3;
        private DataGridView inspectionListGridView;
        private GroupBox groupBox4;
        private Label label6;
        private GroupBox groupBox5;
        private Label statusLabel;
        private PictureBox pictureBox1;
        private TableLayoutPanel tableLayoutPanel1;
        private Label zLabel;
        private Label yLabel;
        private Label xLabel;
        private System.Windows.Forms.Timer timer1;
        private Label finalJudgeLabel;
        private Label processTimeLabel;
        private System.Windows.Forms.Timer processTimer;
        private Label timeLabel;
        private GroupBox groupBox6;
        private Panel panel1;
        private Label label1;
        private GroupBox groupBox7;
        private Label campointLabel;
        private Panel panel2;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Panel panel3;
        private Panel panel5;
        private Panel panel4;
        private Label areaLabel;
        private Panel panel6;
        private Panel panel7;
    }
}
