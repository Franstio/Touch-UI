﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestTCP1.Lib
{
    public class FileLib
    {
        private readonly string _filePath = string.Empty;
        private readonly string _savePath = string.Empty;
        public FileLib()
        {
            string settingPath = Properties.Settings.Default["ImageDirName"]?.ToString() ?? "img";
            string savePath = Properties.Settings.Default["SaveImageDirName"]?.ToString() ?? "img";
            _filePath = settingPath.Contains(":\\") || settingPath.Contains(":/") ? settingPath :  Path.Combine( AppDomain.CurrentDomain.BaseDirectory,
                 settingPath);
            _savePath = savePath.Contains(":\\") || savePath.Contains(":/") ? savePath  : Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                 savePath);
            if (!Directory.Exists(_filePath))
                Directory.CreateDirectory(_filePath);
            if (!Directory.Exists(_savePath)) 
                Directory.CreateDirectory(_savePath);
            Console.WriteLine(_filePath);
            Console.WriteLine(_savePath);
        }

        public Image? ReadImage(string imageName,bool local = false)
        {
            Image img;
            try
            {
                img = Image.FromFile(Path.Combine(local ? _savePath : _filePath, imageName));
                return img;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Image Load Error");
                return null;
            }
        }
        public void SaveImage(string imagePath,string name)
        {
            if (!File.Exists(imagePath))
            {
                MessageBox.Show($"Path {imagePath} Not Found", "File Error");
                return;
            }
            string savepath = Path.Combine(_savePath, name);
            if (File.Exists(savepath))
                File.Delete(savepath);
            var img = Image.FromFile(imagePath);
            img.Save(savepath);
        }
        public string[] GetFolders(string search = "")
        {
            var dirs = Directory.GetDirectories(_filePath);
            if (dirs is null)
            {
                MessageBox.Show($"Path {_filePath} Not Found", "File Error");
                return new string[0];
            }
            return search== "" ? dirs.OrderByDescending(x=>x).ToArray() : dirs.Where(x=>x.Contains(search)).OrderByDescending(x=>x).ToArray();
        }
        public string[] GetFiles(string path,string search="")
        {
            int trycount = 0;
            var files = Directory.GetFiles(path);
            if (files is null)
            {
                MessageBox.Show($"Path {path} Not Found", "File Error");
                return new string[0];
            }
            while (files.Length < 1 && trycount <= 10)
            {
                Thread.Sleep(100);
                files = Directory.GetFiles(path);
                Debug.WriteLineIf(files.Length < 1, $"Retry fetching image on: {path}, count: {trycount+1}");
                trycount += 1;
            }
            return search == "" ? files.OrderByDescending(x=>x).ToArray() : files.Where(x => x.Contains(search)).OrderByDescending(x => x).ToArray();
        }
    }
}
