﻿using Dapper;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestTCP1.Model;

namespace TestTCP1.Lib
{
    public class DbConn
    {
        public string ConnString { get; private set; } = string.Empty;
        public DbConn()
        {
            ConnString = ConfigurationManager.AppSettings["ConnString"] ?? ""; 
        }
        public SqlConnection GetConn()
        {
            return new SqlConnection(ConnString);
        }
        public async Task SavePosition(PosView data)
        {
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Select d.Model,Position as Pos,d.X,d.Y,d.Z,d.CameraCheckPoint,c.CameraPoint From Tbl_Data d left join tbl_campoint c on d.model=c.model Where d.Model=@Model and d.Position=@Position;";
                var find = await conn.QueryAsync<PosView>(query,new {Model=data.Model,Position=data.Pos});
                if (find is null || find?.Count() < 1)
                    query = "Insert Into tbl_data(Model,Position,X,Y,Z,CameraCheckPoint,AreaInspection) Values(@Model,@Position,@X,@Y,@Z,@c,@area)";
                else
                    query = "Update tbl_data set X=@X,Y=@Y,Z=@Z,CameraCheckPoint=@c,AreaInspection=@area where Model=@Model and Position=@Position";
                await conn.ExecuteAsync(query,new {Model= data.Model,Position=data.Pos,X=data.X,Y=data.Y,Z=data.Z,c=data.CameraCheckpoint,area=data.AreaInspection});
                if (find is null || find?.Count() < 1)
                    await SaveCamPoint(data, data.CameraPoint!.Value);
                else
                    await SaveCamPoint(find!.First(),data.CameraPoint!.Value);
            }
        }
        public async Task SaveCamPoint(PosView data,int newCampoint)
        {
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = string.Empty;
                if (data.CameraPoint is null)
                    query = "Insert into tbl_campoint(Model,CameraPoint) Values(@model,@c);";
                else
                    query = "Update tbl_campoint set CameraPoint=@c where model=@model ;";
                await conn.ExecuteAsync(query, new { model = data.Model, c = newCampoint });
            }
        }
        public async Task DeletePosition(PositionModel data)
        {
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Delete Tbl_Data where Model=@model and Position=@pos;";
                await conn.ExecuteAsync(query, new { model = data.Model, pos = data.Pos });
                query = "Update Tbl_Data set Position=Position-1 where Model=@model and Position > @pos;";
                await conn.ExecuteAsync(query, new { model = data.Model, pos = data.Pos });
            }
        }
        public async Task InsertAter(int insertAfterPos,PosView data)
        {
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Update Tbl_Data set Position=Position+1 where Model=@model and Position > @pos;";
                await conn.ExecuteAsync(query, new { model = data.Model, pos = insertAfterPos });
            }
            data.Pos = insertAfterPos+1;
            await SavePosition(data);
        }
        public async Task<List<PositionModel>> GetPositions()
        {
            List<PositionModel> list = new List<PositionModel>();
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Select Model,Position as Pos,X,Y,Z,CameraCheckPoint,AreaInspection From Tbl_Data Order By Model Asc";
                var find = await conn.QueryAsync<PositionModel>(query);
                if (find != null && find?.Count() > 0)
                    list = find.ToList();
            }
            return list;
        }
        public async Task<List<PositionModel>> GetPositionByModel(string Model)
        {
            List<PositionModel> list = new List<PositionModel>();
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Select Model,Position as Pos,X,Y,Z,CameraCheckPoint,AreaInspection From Tbl_Data Where Model=@Model Order By Position Asc";
                var find = await conn.QueryAsync<PositionModel>(query,new {Model=Model});
                if (find != null && find?.Count() > 0)
                    list = find.ToList();
            }
            return list;
        }
        public async Task SavePosRecord(RecordInspectionModel record)
        {
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Insert Into Tbl_Record(Model,Position,X,Y,Z,CameraCheckPoint,AreaInspection,ScanCode,Judgement,ProcessDate) Values(@Model,@Position,@X,@Y,@Z,@c,@area,@scanCode,@judgement,GETDATE())";
                await conn.ExecuteAsync(query, new { Model = record.Model, Position = record.Pos, X = record.X, Y = record.Y, Z = record.Z, c = record.CameraCheckpoint, area = record.AreaInspection,scanCode=record.ScanCode,judgement=record.Judgement });
            }
        }
        public async Task SaveImage(string model,int pos,string imgName)
        {
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Select Count(*) as c from Tbl_Image where Model=@model and position=@position";
                var res = await conn.ExecuteReaderAsync(query, new { model = model, position = pos });
                await res.ReadAsync();
                int c = int.Parse(res[0]?.ToString() ?? "0");
                await res.CloseAsync();
                if (c < 1)
                    query = "Insert into Tbl_image(model,position,imageName) Values(@model,@position,@img)";
                else
                    query = "Update Tbl_Image set imageName=@img where model=@model and position=@position";
                await conn.ExecuteAsync(query, new {model=model,position=pos,img=imgName});
            }
        }
        public async Task<string> GetLocalImage(PositionModel model)
        {
            string img = string.Empty;
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Select imageName From Tbl_Image where Model=@model and Position=@pos";
                var rd = await conn.ExecuteReaderAsync(query, new { model = model.Model, pos = model.Pos });
                if (await rd.ReadAsync())
                {
                    img = rd[0].ToString() ?? string.Empty;
                }

            }
            return img;
        }
        public async Task<List<PosView>> GetPosView(string Model)
        {
            List<PosView> list = new List<PosView>();
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Select d.*,c.CameraPoint From tbl_data d left join tbl_campoint c on d.model=c.model  where d.model=@model";
                var l= await conn.QueryAsync<PosView>(query, new { model = Model });
                list = l.ToList();
            }
            return list;
        }
        public async Task<int?> GetCamPoint(string model)
        {
            int? point = null;
            using (var conn= GetConn())
            {
                await conn.OpenAsync();
                string query = "Select camerapoint from tbl_campoint where model=@model;";
                var rd = await conn.ExecuteReaderAsync(query, new { model = model });
                bool r = await rd.ReadAsync();
                point = r ? int.Parse(rd[0].ToString() ?? "-1") : 0;
            }
            return point;
        }
    }
}
