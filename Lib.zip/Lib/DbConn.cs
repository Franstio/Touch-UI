﻿using Dapper;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestTCP1.Model;

namespace TestTCP1.Lib
{
    public class DbConn
    {
        public string ConnString { get; private set; } = string.Empty;
        public DbConn()
        {
            ConnString = ConfigurationManager.AppSettings["ConnString"] ?? ""; 
        }
        public SqlConnection GetConn()
        {
            return new SqlConnection(ConnString);
        }
        public async Task SavePosition(PositionModel data)
        {
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Select Model,Position as Pos,X,Y,Z,CameraCheckPoint From Tbl_Data Where Model=@Model and Position=@Position";
                var find = await conn.QueryAsync<PositionModel>(query,new {Model=data.Model,Position=data.Pos});
                if (find is null || find?.Count() < 1)
                    query = "Insert Into tbl_data(Model,Position,X,Y,Z,CameraCheckPoint,AreaInspection) Values(@Model,@Position,@X,@Y,@Z,@c,@area)";
                else
                    query = "Update tbl_data set X=@X,Y=@Y,Z=@Z,CameraCheckPoint=@c,AreaInspection=@area where Model=@Model and Position=@Position";
                await conn.ExecuteAsync(query,new {Model= data.Model,Position=data.Pos,X=data.X,Y=data.Y,Z=data.Z,c=data.CameraCheckpoint,area=data.AreaInspection});
            }
        }
        public async Task DeletePosition(PositionModel data)
        {
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Delete Tbl_Data where Model=@model and Position=@pos;";
                await conn.ExecuteAsync(query, new { model = data.Model, pos = data.Pos });
                query = "Update Tbl_Data set Position=Position-1 where Model=@model and Position > @pos;";
                await conn.ExecuteAsync(query, new { model = data.Model, pos = data.Pos });
            }
        }
        public async Task InsertAter(int insertAfterPos,PositionModel data)
        {
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Update Tbl_Data set Position=Position+1 where Model=@model and Position > @pos;";
                await conn.ExecuteAsync(query, new { model = data.Model, pos = insertAfterPos });
            }
            data.Pos = insertAfterPos+1;
            await SavePosition(data);
        }
        public async Task<List<PositionModel>> GetPositions()
        {
            List<PositionModel> list = new List<PositionModel>();
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Select Model,Position as Pos,X,Y,Z,CameraCheckPoint,AreaInspection From Tbl_Data Order By Model Asc";
                var find = await conn.QueryAsync<PositionModel>(query);
                if (find != null && find?.Count() > 0)
                    list = find.ToList();
            }
            return list;
        }
        public async Task<List<PositionModel>> GetPositionByModel(string Model)
        {
            List<PositionModel> list = new List<PositionModel>();
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Select Model,Position as Pos,X,Y,Z,CameraCheckPoint,AreaInspection From Tbl_Data Where Model=@Model Order By Position Asc";
                var find = await conn.QueryAsync<PositionModel>(query,new {Model=Model});
                if (find != null && find?.Count() > 0)
                    list = find.ToList();
            }
            return list;
         }
        public async Task SavePosRecord(RecordInspectionModel record)
        {
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Insert Into Tbl_Record(Model,Position,X,Y,Z,CameraCheckPoint,AreaInspection,ScanCode,Judgement,ProcessDate) Values(@Model,@Position,@X,@Y,@Z,@c,@area,@scanCode,@judgement,GETDATE())";
                await conn.ExecuteAsync(query, new { Model = record.Model, Position = record.Pos, X = record.X, Y = record.Y, Z = record.Z, c = record.CameraCheckpoint, area = record.AreaInspection,scanCode=record.ScanCode,judgement=record.Judgement });
            }
        }
        public async Task SaveImage(string model,int pos,string imgName)
        {
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Select Count(*) as c from Tbl_Image where Model=@model and position=@position";
                var res = await conn.ExecuteReaderAsync(query, new { model = model, position = pos });
                await res.ReadAsync();
                int c = int.Parse(res[0]?.ToString() ?? "0");
                await res.CloseAsync();
                if (c < 1)
                    query = "Insert into Tbl_image(model,position,imageName) Values(@model,@position,@img)";
                else
                    query = "Update Tbl_Image set imageName=@img where model=@model and position=@position";
                await conn.ExecuteAsync(query, new {model=model,position=pos,img=imgName});
            }
        }
        public async Task<string> GetLocalImage(PositionModel model)
        {
            string img = string.Empty;
            using (var conn = GetConn())
            {
                await conn.OpenAsync();
                string query = "Select imageName From Tbl_Image where Model=@model and Position=@pos";
                var rd = await conn.ExecuteReaderAsync(query, new { model = model.Model, pos = model.Pos });
                if (await rd.ReadAsync())
                {
                    img = rd[0].ToString() ?? string.Empty;
                }

            }
            return img;
        }
    }
}
