﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestTCP1.Lib;
using TestTCP1.Model;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Button = System.Windows.Forms.Button;

namespace TestTCP1.Forms
{
    public partial class SettingParameterControl : UserControl
    {
        private string _image = string.Empty;
        private string _imageFull = string.Empty;
        private readonly FileLib fileLib = new FileLib();
        public string Model { get; set; } = string.Empty;
        private PositionModel curModel = new PositionModel();
        private readonly TCPConn conn = TCPConn.getInstance();
        private readonly DbConn dbCon = new DbConn();
        private readonly Mapper map = AutoMapConfig.GetMapper();
        private readonly Button[] minusButtons = new Button[3];
        private List<PositionModel> Positions = new List<PositionModel>();
        public SettingParameterControl(string Model)
        {
            InitializeComponent();
            minusButtons = new Button[] { button5, button8, button10 };
            this.Model = Model;
            checkMinusButton();
            DataTable dt = new DataTable();
            dt.Columns.Add("Point");
            dt.Columns.Add("Area");
            dt.Columns.Add("Camera Set");
            parameterDatsGridView.DataSource = dt;
        }

        private async void SettingParameterControl_Load(object sender, EventArgs e)
        {
            await ReloadData();
            await LoadPosition();
            this.Invoke(new Action(() => updatePositionAll()));
            runningModel.Text = "Model: " + Model;
        }
        private void checkMinusButton()
        {
            minusButtons[0].Enabled = curModel.X > 0;
            minusButtons[1].Enabled = curModel.Y > 0;
            minusButtons[2].Enabled = curModel.Z > 0;
        }
        private async Task ReloadData()
        {

            if (!TCPConn.isRunning)
                await conn.StartConnection();
            var res = await dbCon.GetPositionByModel(Model);
            if (res is null || res.Count < 1)
                return;
            Positions = res;
            var v = map.Map<List<ModelPosView>>(res);
            parameterDatsGridView.DataSource = v;
            parameterDatsGridView.Refresh();
            curModel = new PositionModel();
            curModel.Model = this.Model;
            curModel.Pos = v.Select(x => x.Pos).Max() + 1;
            pointLabel.Invoke(new Action(() =>
            {
                pointLabel.Text = "Point: " + curModel.Pos;
            }));
            inspectionAreaBox.Invoke(new Action(() =>
            {
                inspectionAreaBox.Text = "";
            }));
            cameraTriggerBox.Invoke(new Action(() =>
            {
                cameraTriggerBox.Text = "";
            }));
        }
        private async void moveCoordinate(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            string res = string.Empty, result = string.Empty;
            switch (b.Tag.ToString())
            {
                case ">":
                    await conn.SendCommand("WR MR14 1");
                    result = await conn.SendCommand("RD CM8830.L");
                    res = "X";
                    curModel.X = decimal.Parse(result);
                    break;
                case "<":
                    await conn.SendCommand("WR MR15 1");
                    result = await conn.SendCommand("RD CM8830.L");
                    res = "X";
                    curModel.X = decimal.Parse(result);
                    break;
                case "^":
                    await conn.SendCommand("WR MR12 1");
                    result = await conn.SendCommand("RD CM8870");
                    res = "Y";
                    curModel.Y = decimal.Parse(result);
                    break;
                case "V":
                    await conn.SendCommand("WR MR13 1");
                    result = await conn.SendCommand("RD CM8870.L");
                    res = "Y";
                    curModel.Y = decimal.Parse(result);
                    break;
                case "+":
                    await conn.SendCommand("WR MR10 1");
                    result = await conn.SendCommand("RD CM8910.L");
                    res = "Z";
                    curModel.Z = decimal.Parse(result);
                    break;
                case "-":
                    await conn.SendCommand("WR MR11 1");
                    result = await conn.SendCommand("RD CM8910.L");
                    res = "Z";
                    curModel.Z = decimal.Parse(result);
                    break;
                default:
                    return;
            }
            this.Invoke(new Action(() => updatePosition(res)));
        }

        private void updatePosition(string label)
        {
            switch (label)
            {
                case "X":
                    xLabel.Text = $"X: {(curModel.X / 1600 * 20).ToString("0.00")} mm";
                    break;
                case "Y":
                    yLabel.Text = $"Y: {(curModel.Y / 1600 * 20).ToString("0.00")} mm";
                    break;
                case "Z":
                    zLabel.Text = $"Z: {(curModel.Z / 1600 * 20).ToString("0.00")} mm";
                    break;
            }
            checkMinusButton();
        }
        private void updatePositionAll()
        {
            xLabel.Text = $"X: {(curModel.X / 1600 * 20).ToString("0.00")} mm";
            yLabel.Text = $"Y: {(curModel.Y / 1600 * 20).ToString("0.00")} mm";
            zLabel.Text = $"Z: {(curModel.Z / 1600 * 20).ToString("0.00")} mm";
            checkMinusButton();
        }
        private async Task LoadPosition()
        {
            string res = string.Empty;
            res = await conn.SendCommand("RD CM8830.L");
            curModel.X = decimal.Parse(res);
            res = await conn.SendCommand("RD CM8870");
            curModel.Y = decimal.Parse(res);
            res = await conn.SendCommand("RD CM8910.L");
            curModel.Z = decimal.Parse(res);
        }

        private async void button12_Click(object sender, EventArgs e)
        {
            button12.Invoke(new Action(() => { button12.Enabled = false; }));
            curModel.CameraCheckpoint = cameraTriggerBox.Text;
            curModel.Model = Model;
            curModel.AreaInspection = inspectionAreaBox.Text;
            curModel.X = curModel.X / 1600 * 20;
            curModel.Y = curModel.Y / 1600 * 20;
            curModel.Z = curModel.Z / 1600 * 20;
            await dbCon.SavePosition(curModel);
            await dbCon.SaveImage(curModel.Model, curModel.Pos, _image);
            fileLib.SaveIMage(_imageFull, _image);
            pictureBox1.Invoke(new Action(() => pictureBox1.Image = null));
            await ReloadData();
            button12.Invoke(new Action(() => { button12.Enabled = true; }));
        }

        private async void button11_Click(object sender, EventArgs e)
        {
            this.button11.Invoke(new Action(() => { button11.Enabled = false; }));
            curModel.AreaInspection = inspectionAreaBox.Text;
            curModel.CameraCheckpoint = cameraTriggerBox.Text;
            await conn.SendCommand($"WR W0F2 {cameraTriggerBox.Text}");
            await conn.SendCommand("WR MR400 1");
            Thread.Sleep(100);
            await conn.SendCommand("WR MR400 0");
            //            MessageBox.Show("Send Trigger Command Complete", "Send Trigger Command");
            Thread.Sleep(100);
            await GetTriggerImage(curModel);
            this.button11.Invoke(new Action(() => { button11.Enabled = true; }));
        }
        private async Task GetTriggerImage(PositionModel data)
        {
            string foldername = $"{DateTime.Now.ToString("yyMMdd")}";
            string[] folders = fileLib.GetFolders(foldername);
            if (folders.Length < 1)
            {
                MessageBox.Show($"No Folder with prefix {foldername} Found", "Error");
                return;
            }
            string latestDir = Path.Combine(folders[0], "CAM1");
            string[] img = fileLib.GetFiles(latestDir);
            FileInfo file = new FileInfo(img[0]);
            _image = file.Name;
            _imageFull = img[0];

            pictureBox1.Invoke(new Action(() =>
            {
                pictureBox1.Image = Image.FromFile(img[0]);
            }));

        }
        private async void button2_Click(object sender, EventArgs e)
        {

            button2.Invoke(new Action(() => { button2.Enabled = false; }));
            int newPos = int.Parse(insertAfter.Value.ToString());
            curModel.Pos = newPos + 1;
            curModel.AreaInspection = inspectionAreaBox.Text;
            curModel.CameraCheckpoint = cameraTriggerBox.Text;
            await dbCon.InsertAter(newPos, curModel);
            await ReloadData();
            button2.Invoke(new Action(() => { button2.Enabled = true; }));
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            button3.Invoke(new Action(() => { button3.Enabled = false; }));
            curModel.Pos = int.Parse(delPos.Value.ToString());
            curModel.Model = Model;
            await dbCon.DeletePosition(curModel);
            await ReloadData();
            button3.Invoke(new Action(() => { button3.Enabled = true; }));
        }
        private async Task GotoPoint(PositionModel data)
        {
            string res = string.Empty;
            curModel.X = data.X * 1600 / 20;
            curModel.Y = data.Y * 1600 / 20;
            curModel.Z = data.Z * 1600 / 20;
            string xVal = String.Format("{0:0}", data.X);
            string yVal = String.Format("{0:0}", data.Y);
            string zVal = String.Format("{0:0}", data.Z);
            res = await conn.SendCommand($"WR CM8010 {xVal}");
            res = await conn.SendCommand($"WR CM8210 {yVal}");
            res = await conn.SendCommand($"WR CM8410 {zVal}");

            await conn.SendCommand($"WR MR800 1");
            Thread.Sleep(100);
            await conn.SendCommand($"WR MR800 0");

            string img = await dbCon.GetLocalImage(data);
            pictureBox1.Invoke(new Action(() => pictureBox1.Image = fileLib.ReadImage(img,true)));
        }
        private async void button1_Click(object sender, EventArgs e)
        {
            int go = int.Parse(gotoValue.Value.ToString());
            var find = Positions.Where(x => x.Pos == go).FirstOrDefault();
            if (find is null)
                return;
            curModel = find;
            await GotoPoint(curModel);

            this.Invoke(new Action(() =>
            {
                pointLabel.Text = "Point: " + curModel.Pos;
                cameraTriggerBox.Text = curModel.CameraCheckpoint;
                inspectionAreaBox.Text = curModel.AreaInspection;
                xLabel.Text = $"X: {(curModel.X / 1600 * 20).ToString("0.00")} mm";
                yLabel.Text = $"Y: {(curModel.Y / 1600 * 20).ToString("0.00")} mm";
                zLabel.Text = $"Z: {(curModel.Z / 1600 * 20).ToString("0.00")} mm";
            }));
            return;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timeLabel.Invoke(new Action(() =>
            {
                timeLabel.Text = $"Date: {DateTime.Now.ToString("dd MMM yyyy")}\nTime: {DateTime.Now.ToString("HH:mm:ss")}";
            }));
        }
    }
}
