﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestTCP1.Lib;
using TestTCP1.Model;

namespace TestTCP1.Forms
{
    public partial class DashboardControl : UserControl
    {
        public string Model { get; private set; } = string.Empty;
        private readonly FileLib fileLib = new FileLib();
        private readonly DbConn dbCon = new DbConn();
        private readonly TCPConn conn = TCPConn.getInstance();
        private readonly TCPConn? conn2 = null;
        private List<PositionModel> Positions = new List<PositionModel>();
        private List<InspectionView> InspectionViews = new List<InspectionView>();
        private readonly Mapper mapper = AutoMapConfig.GetMapper();
        private DateTime startTime = DateTime.Now;
        public DashboardControl()
        {
            InitializeComponent();
            textBox1.Enabled = false;
        }
        protected override void OnControlRemoved(ControlEventArgs e)
        {
            conn2?.StopConnection();
            base.OnControlRemoved(e);
        }
        public DashboardControl(string _Model)
        {
            InitializeComponent();


            conn2 = TCPConn.newInstance();
            Model = _Model;
            runningModel.Text = "Running Model: " + Model;
            DataTable dt = new DataTable();
            dt.Columns.Add("Area");
            dt.Columns.Add("Judgement");
            inspectionListGridView.DataSource = dt;
        }
        private async Task GetPos()
        {
            Positions = await dbCon.GetPositionByModel(Model);
            InspectionViews = mapper.Map<List<InspectionView>>(Positions);
            this.inspectionListGridView.Invoke(new Action(() =>
            {
                inspectionListGridView.DataSource = InspectionViews;
                inspectionListGridView.Refresh();
            }));
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void SwitchControlState(string status)
        {
            switch (status)
            {
                case "waiting":
                    pictureBox1.Invoke(new Action(() => pictureBox1.Image = null));
                    scanLabel.Invoke(new Action(() => scanLabel.Text = textBox1.Text));
                    textBox1.Invoke(new Action(() => textBox1.Enabled = false));
                    statusLabel.Invoke(new Action(() => statusLabel.Text = "Waiting for start button (In-Progress)"));
                    break;
                case "running":
                    statusLabel.Invoke(new Action(() =>
                    {
                        statusLabel.Text = "Running...";
                    }));
                    break;
                case "complete":

                    scanLabel.Invoke(new Action(() => scanLabel.Text = string.Empty));
                    textBox1.Invoke(new Action(() => { textBox1.Enabled = true; textBox1.Text = string.Empty; })); ;
                    statusLabel.Invoke(new Action(() => statusLabel.Text = "Running Process Complete"));
                    break;
            }
        }
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter)
                return;
            finalJudgeLabel.Text = string.Empty;
            areaLabel.Text = string.Empty;
            decisionLabel.Text = string.Empty;
            processTimeLabel.Invoke(new Action(() => processTimeLabel.Text = "Process Time: 00:00:00"));
            startTime = DateTime.Now;
            processTimer.Enabled = true;
            processTimer.Start();
            Task.Run(ScanRun);
        }
        private async Task ScanRun()
        {
            await GetPos();
            SwitchControlState("waiting");
            string res = string.Empty;

            do
            {
                res = await conn.SendCommand($"RD MR8000");
            }
            while (!res.Contains("1") && !res.Contains("ok"));

            SwitchControlState("running");
            for (int i = 0; i < Positions.Count; i++)
            {
                var _pos = Positions[i];
                await StartProcess(_pos);
                var isPassed = await Trigger(_pos.CameraCheckpoint);
                InspectionViews[i].Judgement = isPassed ? "PASS" : "NG";
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                Task.Run(() => LoadImage(Positions[i], isPassed));
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                RecordInspectionModel record = mapper.Map<RecordInspectionModel>(_pos);
                record.ScanCode = textBox1.Text;
                record.Judgement = InspectionViews[i].Judgement;
                await dbCon.SavePosRecord(record);
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                Task.Run(new Action(() =>
                {
                    this.inspectionListGridView.Invoke(new Action(() =>
                    {
                        inspectionListGridView.DataSource = InspectionViews;
                        inspectionListGridView.Refresh();
                    }));

                    this.areaLabel.Invoke(new Action(() => areaLabel.Text = _pos.AreaInspection));
                    this.decisionLabel.Invoke(new Action(() =>
                    {
                        decisionLabel.Text = record.Judgement;
                        decisionLabel.ForeColor = isPassed ? Color.Lime : Color.DarkRed;
                    }));
                }));
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
            }
            string res1, res2;
            do
            {
                await StartProcess(new PositionModel() { X = 0, Y = 0, Z = 0 });
                res1 = await conn.SendCommand("WR MR8000 0");
                res2 = await conn.SendCommand("WR DM0 0");
            }
            while (!(res1.ToLower().Contains("ok") || res1.ToLower().Contains("1")) || !(res2.ToLower().Contains("ok") || res2.ToLower().Contains("1")));
            SwitchControlState("complete");
            finalJudgeLabel.Invoke(new Action(() =>
            {
                bool finalJudge = InspectionViews.Select(x => x.Judgement).Any(x => x.Contains("NG"));
                finalJudgeLabel.ForeColor = finalJudge ? Color.DarkRed : Color.Lime;
                finalJudgeLabel.Text = finalJudge ? "FAIL" : "PASS";
            }));
            processTimer.Stop();
            processTimer.Enabled = false;
        }
        private async Task LoadImage(PositionModel position, bool isPassed)
        {
            Thread.Sleep(5);
            string imgPath = isPassed ? await dbCon.GetLocalImage(position) : GetTriggerImgPath();
            //                string imgPath = isPassed ? await dbCon.GetLocalImage(Positions[i]) : GetTriggerImgPath();
            pictureBox1.Invoke(new Action(() =>
            {
                pictureBox1.Image = fileLib.ReadImage(imgPath, isPassed);//isPassed ? fileLib.ReadImage(imgPath) : Image.FromFile(imgPath);
            }));
        }
        private string GetTriggerImgPath()
        {
            string foldername = $"{DateTime.Now.ToString("yyMMdd")}";
            string[] folders = fileLib.GetFolders(foldername);
            if (folders.Length < 1)
            {
                MessageBox.Show($"No Folder with prefix {foldername} Found", "Error");
                return string.Empty;
            }
            string latestDir = Path.Combine(folders[0], "CAM1");
            string[] img = fileLib.GetFiles(latestDir);
            return img.Length < 1 ? "" : img[0];
        }

        private async Task StartProcess(PositionModel data)
        {
            if (!TCPConn.isRunning)
                await conn.StartConnection();
            await conn.SendCommand("WR MR300 0");
            string res = string.Empty;
            string xVal = String.Format("{0:0}", data.X * 1600 / 20);
            string yVal = String.Format("{0:0}", data.Y * 1600 / 20);
            string zVal = String.Format("{0:0}", data.Z * 1600 / 20);
            res = await conn.SendCommand($"WR CM8010 {xVal}");
            res = await conn.SendCommand($"WR CM8210 {yVal}");
            res = await conn.SendCommand($"WR CM8410 {zVal}");

            res = await conn.SendCommand($"WR W0F2 {data.CameraCheckpoint}");
            await conn.SendCommand("WR MR300 1");
            bool[] confirms = new bool[3];
            do
            {
                confirms[0] = (await conn.SendCommand($"RD CR8401")).Contains("1");
                confirms[1] = (await conn.SendCommand($"RD CR8501")).Contains("1");
                confirms[2] = (await conn.SendCommand($"RD CR8601")).Contains("1");
            }
            while (confirms.Any(x => x == false));
            string test = string.Empty;
        }
        private async Task<bool> Trigger(string checkPoint)
        {
            //res = await conn.SendCommand("WR MR400 1");
            //Thread.Sleep(10);
            //res = await conn.SendCommand("WR MR400 0");
            string res = await conn.SendCommand("RD MR1000");
            if (res.Contains("1"))
                return true;
            res = await conn.SendCommand("RD MR1001");
            if (res.Contains("1"))
                return false;
            throw new Exception("Incorrect trigger output");
        }

        private async void DashboardControl_Load(object sender, EventArgs e)
        {
            if (Model == null || Model == string.Empty)
                return;
            if (!TCPConn.isRunning)
                await conn.StartConnection();
            await GetPos();
        }
        private void checkPhoto()
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Task.Run(new Action(async () =>
            {
                timeLabel.Invoke(new Action(() =>
                {
                    timeLabel.Text = $"Date: {DateTime.Now.ToString("dd MMM yyyy")}\nTime: {DateTime.Now.ToString("HH:mm:ss")}";
                }));

                //string res = string.Empty;
                //decimal val = 0;
                //if (conn2 is null)
                //    return;
                //if (!conn2.getIsRunning())
                //    await conn2.StartConnection();
                //res = await conn2.SendCommand("RD CM8830.L");
                //if (!decimal.TryParse(res, out val))
                //    val = 0;
                //xLabel.Invoke(new Action(() =>
                //xLabel.Text = $"X: {(val / 1600 * 20).ToString("0.00")} mm"));
                //res = await conn2.SendCommand("RD CM8870");
                //if (!decimal.TryParse(res, out val))
                //    val = 0;
                //yLabel.Invoke(new Action(() =>
                //yLabel.Text = $"Y: {(val / 1600 * 20).ToString("0.00")} mm"));
                //res = await conn2.SendCommand("RD CM8910.L");
                //if (!decimal.TryParse(res, out val))
                //    val = 0;
                //zLabel.Invoke(new Action(() =>
                //zLabel.Text = $"Z: {(val / 1600 * 20).ToString("0.00")} mm"));
            }));
        }

        private void timeLabel_Click(object sender, EventArgs e)
        {

        }

        private void scanLabel_Click(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void labeld_Click(object sender, EventArgs e)
        {
        }

        private void areaLabel_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {
        }

        private void inspectionListGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {
        }

        private void label6_Click(object sender, EventArgs e)
        {
        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {
        }

        private void statusLabel_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void zLabel_Click(object sender, EventArgs e)
        {
        }

        private void yLabel_Click(object sender, EventArgs e)
        {
        }

        private void xLabel_Click(object sender, EventArgs e)
        {
        }

        private void runningModel_Click(object sender, EventArgs e)
        {
        }

        private void processTimer_Tick(object sender, EventArgs e)
        {
            var elapsed = DateTime.Now - startTime;
            processTimeLabel.Invoke(new Action(() =>
            {
                processTimeLabel.Text = $"Process Time: {elapsed.Hours.ToString("00")}:{elapsed.Minutes.ToString("00")}:{elapsed.Seconds.ToString("00")}";
            }));
        }
    }
}
