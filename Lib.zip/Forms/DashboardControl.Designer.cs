﻿namespace TestTCP1.Forms
{
    partial class DashboardControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            runningModel = new Label();
            timeLabel = new Label();
            groupBox1 = new GroupBox();
            scanLabel = new Label();
            label3 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            groupBox2 = new GroupBox();
            decisionLabel = new Label();
            labeld = new Label();
            areaLabel = new Label();
            label4 = new Label();
            groupBox3 = new GroupBox();
            inspectionListGridView = new DataGridView();
            groupBox4 = new GroupBox();
            label6 = new Label();
            groupBox5 = new GroupBox();
            statusLabel = new Label();
            pictureBox1 = new PictureBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            zLabel = new Label();
            yLabel = new Label();
            xLabel = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            finalJudgeLabel = new Label();
            processTimeLabel = new Label();
            processTimer = new System.Windows.Forms.Timer(components);
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)inspectionListGridView).BeginInit();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // runningModel
            // 
            runningModel.AutoSize = true;
            runningModel.Font = new Font("Segoe UI", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            runningModel.Location = new Point(11, 8);
            runningModel.Name = "runningModel";
            runningModel.Size = new Size(197, 32);
            runningModel.TabIndex = 0;
            runningModel.Text = "Running Model: ";
            runningModel.TextAlign = ContentAlignment.MiddleCenter;
            runningModel.Click += runningModel_Click;
            // 
            // timeLabel
            // 
            timeLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            timeLabel.AutoSize = true;
            timeLabel.Location = new Point(546, 31);
            timeLabel.Name = "timeLabel";
            timeLabel.Size = new Size(36, 30);
            timeLabel.TabIndex = 1;
            timeLabel.Text = "Date:\r\nTime:";
            timeLabel.TextAlign = ContentAlignment.MiddleCenter;
            timeLabel.Click += timeLabel_Click;
            // 
            // groupBox1
            // 
            groupBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            groupBox1.Controls.Add(scanLabel);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Location = new Point(546, 65);
            groupBox1.Margin = new Padding(3, 2, 3, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 2, 3, 2);
            groupBox1.Size = new Size(261, 93);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Serial No.";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // scanLabel
            // 
            scanLabel.AutoSize = true;
            scanLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            scanLabel.ForeColor = SystemColors.Highlight;
            scanLabel.Location = new Point(93, 70);
            scanLabel.Name = "scanLabel";
            scanLabel.Size = new Size(49, 15);
            scanLabel.TabIndex = 3;
            scanLabel.Text = "123456";
            scanLabel.Click += scanLabel_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(71, 56);
            label3.Name = "label3";
            label3.Size = new Size(91, 15);
            label3.TabIndex = 2;
            label3.Text = "RUNNING S/N:";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(88, 14);
            label2.Name = "label2";
            label2.Size = new Size(64, 15);
            label2.TabIndex = 1;
            label2.Text = "Scan Code";
            label2.Click += label2_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(40, 32);
            textBox1.Margin = new Padding(3, 2, 3, 2);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(164, 23);
            textBox1.TabIndex = 0;
            textBox1.TextAlign = HorizontalAlignment.Center;
            textBox1.TextChanged += textBox1_TextChanged;
            textBox1.KeyDown += textBox1_KeyDown;
            // 
            // groupBox2
            // 
            groupBox2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            groupBox2.Controls.Add(decisionLabel);
            groupBox2.Controls.Add(labeld);
            groupBox2.Controls.Add(areaLabel);
            groupBox2.Controls.Add(label4);
            groupBox2.Location = new Point(546, 163);
            groupBox2.Margin = new Padding(3, 2, 3, 2);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 2, 3, 2);
            groupBox2.Size = new Size(256, 80);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "Inspection";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // decisionLabel
            // 
            decisionLabel.AutoSize = true;
            decisionLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            decisionLabel.ForeColor = Color.Lime;
            decisionLabel.Location = new Point(112, 63);
            decisionLabel.Name = "decisionLabel";
            decisionLabel.Size = new Size(35, 15);
            decisionLabel.TabIndex = 7;
            decisionLabel.Text = "PASS";
            decisionLabel.Click += label5_Click;
            // 
            // labeld
            // 
            labeld.AutoSize = true;
            labeld.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            labeld.Location = new Point(102, 45);
            labeld.Name = "labeld";
            labeld.Size = new Size(57, 15);
            labeld.TabIndex = 6;
            labeld.Text = "Decision:";
            labeld.Click += labeld_Click;
            // 
            // areaLabel
            // 
            areaLabel.AutoSize = true;
            areaLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            areaLabel.Location = new Point(121, 30);
            areaLabel.Name = "areaLabel";
            areaLabel.Size = new Size(19, 15);
            areaLabel.TabIndex = 5;
            areaLabel.Text = "J6";
            areaLabel.Click += areaLabel_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(88, 15);
            label4.Name = "label4";
            label4.Size = new Size(90, 15);
            label4.TabIndex = 4;
            label4.Text = "Area Checking:";
            label4.Click += label4_Click;
            // 
            // groupBox3
            // 
            groupBox3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            groupBox3.Controls.Add(inspectionListGridView);
            groupBox3.Location = new Point(543, 243);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(3, 2, 3, 2);
            groupBox3.Size = new Size(258, 197);
            groupBox3.TabIndex = 4;
            groupBox3.TabStop = false;
            groupBox3.Text = "Inspection List:";
            groupBox3.Enter += groupBox3_Enter;
            // 
            // inspectionListGridView
            // 
            inspectionListGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            inspectionListGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            inspectionListGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            inspectionListGridView.Dock = DockStyle.Fill;
            inspectionListGridView.Location = new Point(3, 18);
            inspectionListGridView.Margin = new Padding(3, 2, 3, 2);
            inspectionListGridView.Name = "inspectionListGridView";
            inspectionListGridView.ReadOnly = true;
            inspectionListGridView.RowHeadersWidth = 51;
            inspectionListGridView.RowTemplate.Height = 29;
            inspectionListGridView.Size = new Size(252, 177);
            inspectionListGridView.TabIndex = 0;
            inspectionListGridView.CellContentClick += inspectionListGridView_CellContentClick;
            // 
            // groupBox4
            // 
            groupBox4.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            groupBox4.Controls.Add(label6);
            groupBox4.Location = new Point(546, 445);
            groupBox4.Margin = new Padding(3, 2, 3, 2);
            groupBox4.Name = "groupBox4";
            groupBox4.Padding = new Padding(3, 2, 3, 2);
            groupBox4.Size = new Size(256, 66);
            groupBox4.TabIndex = 5;
            groupBox4.TabStop = false;
            groupBox4.Text = "Log File:";
            groupBox4.Enter += groupBox4_Enter;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label6.Location = new Point(16, 30);
            label6.Name = "label6";
            label6.Size = new Size(94, 15);
            label6.TabIndex = 8;
            label6.Text = "log1123445.txt";
            label6.Click += label6_Click;
            // 
            // groupBox5
            // 
            groupBox5.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            groupBox5.Controls.Add(statusLabel);
            groupBox5.Location = new Point(11, 445);
            groupBox5.Margin = new Padding(3, 2, 3, 2);
            groupBox5.Name = "groupBox5";
            groupBox5.Padding = new Padding(3, 2, 3, 2);
            groupBox5.Size = new Size(526, 66);
            groupBox5.TabIndex = 9;
            groupBox5.TabStop = false;
            groupBox5.Text = "Status:";
            groupBox5.Enter += groupBox5_Enter;
            // 
            // statusLabel
            // 
            statusLabel.AutoSize = true;
            statusLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            statusLabel.Location = new Point(16, 30);
            statusLabel.Name = "statusLabel";
            statusLabel.Size = new Size(94, 15);
            statusLabel.TabIndex = 8;
            statusLabel.Text = "log1123445.txt";
            statusLabel.Click += statusLabel_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Location = new Point(11, 97);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(527, 344);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.Controls.Add(zLabel, 2, 0);
            tableLayoutPanel1.Controls.Add(yLabel, 1, 0);
            tableLayoutPanel1.Controls.Add(xLabel, 0, 0);
            tableLayoutPanel1.Location = new Point(11, 73);
            tableLayoutPanel1.Margin = new Padding(3, 2, 3, 2);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(526, 20);
            tableLayoutPanel1.TabIndex = 11;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // zLabel
            // 
            zLabel.AutoSize = true;
            zLabel.Dock = DockStyle.Fill;
            zLabel.Location = new Point(353, 0);
            zLabel.Name = "zLabel";
            zLabel.Size = new Size(170, 20);
            zLabel.TabIndex = 2;
            zLabel.Text = "Z: 0.00 mm";
            zLabel.TextAlign = ContentAlignment.MiddleCenter;
            zLabel.Click += zLabel_Click;
            // 
            // yLabel
            // 
            yLabel.AutoSize = true;
            yLabel.Dock = DockStyle.Fill;
            yLabel.Location = new Point(178, 0);
            yLabel.Name = "yLabel";
            yLabel.Size = new Size(169, 20);
            yLabel.TabIndex = 1;
            yLabel.Text = "Y: 0.00 mm";
            yLabel.TextAlign = ContentAlignment.MiddleCenter;
            yLabel.Click += yLabel_Click;
            // 
            // xLabel
            // 
            xLabel.AutoSize = true;
            xLabel.Dock = DockStyle.Fill;
            xLabel.Location = new Point(3, 0);
            xLabel.Name = "xLabel";
            xLabel.Size = new Size(169, 20);
            xLabel.TabIndex = 0;
            xLabel.Text = "X: 0.00 mm";
            xLabel.TextAlign = ContentAlignment.MiddleCenter;
            xLabel.Click += xLabel_Click;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Tick += timer1_Tick;
            // 
            // finalJudgeLabel
            // 
            finalJudgeLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            finalJudgeLabel.AutoSize = true;
            finalJudgeLabel.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            finalJudgeLabel.Location = new Point(688, 19);
            finalJudgeLabel.Name = "finalJudgeLabel";
            finalJudgeLabel.Size = new Size(0, 45);
            finalJudgeLabel.TabIndex = 12;
            // 
            // processTimeLabel
            // 
            processTimeLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            processTimeLabel.AutoSize = true;
            processTimeLabel.Location = new Point(11, 47);
            processTimeLabel.Name = "processTimeLabel";
            processTimeLabel.Size = new Size(124, 15);
            processTimeLabel.TabIndex = 13;
            processTimeLabel.Text = "Process Time: 00:00:00";
            processTimeLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // processTimer
            // 
            processTimer.Interval = 1000;
            processTimer.Tick += processTimer_Tick;
            // 
            // DashboardControl
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            Controls.Add(processTimeLabel);
            Controls.Add(finalJudgeLabel);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox5);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(timeLabel);
            Controls.Add(runningModel);
            Margin = new Padding(3, 2, 3, 2);
            Name = "DashboardControl";
            Size = new Size(810, 517);
            Load += DashboardControl_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)inspectionListGridView).EndInit();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label runningModel;
        private Label timeLabel;
        private GroupBox groupBox1;
        private Label scanLabel;
        private Label label3;
        private Label label2;
        private TextBox textBox1;
        private GroupBox groupBox2;
        private Label decisionLabel;
        private Label labeld;
        private Label areaLabel;
        private Label label4;
        private GroupBox groupBox3;
        private DataGridView inspectionListGridView;
        private GroupBox groupBox4;
        private Label label6;
        private GroupBox groupBox5;
        private Label statusLabel;
        private PictureBox pictureBox1;
        private TableLayoutPanel tableLayoutPanel1;
        private Label zLabel;
        private Label yLabel;
        private Label xLabel;
        private System.Windows.Forms.Timer timer1;
        private Label finalJudgeLabel;
        private Label processTimeLabel;
        private System.Windows.Forms.Timer processTimer;
    }
}
