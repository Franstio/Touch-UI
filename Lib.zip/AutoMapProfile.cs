﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestTCP1.Model;

namespace TestTCP1
{
    public class AutoMapConfig
    {
        public static Mapper GetMapper()
        {
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<PositionModel, JudgementView>();
                cfg.CreateMap<PositionModel,ModelPosView>().ForMember(x=>x.Area,x=>x.MapFrom(z=>z.AreaInspection));
                cfg.CreateMap<PositionModel, InspectionView>().ForMember(x => x.Area, x => x.MapFrom(z => z.AreaInspection));
                cfg.CreateMap<PositionModel, RecordInspectionModel>();
                });
            return new Mapper(config);
        }
    }
}
