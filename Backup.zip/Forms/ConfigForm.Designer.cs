﻿namespace TestTCP1.Forms
{
    partial class ConfigForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            button15 = new Button();
            label4 = new Label();
            portBox = new TextBox();
            label3 = new Label();
            ipBox = new TextBox();
            statusLabel = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(statusLabel);
            groupBox1.Controls.Add(button15);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(portBox);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(ipBox);
            groupBox1.Dock = DockStyle.Top;
            groupBox1.Location = new Point(0, 0);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(338, 116);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Connection";
            // 
            // button15
            // 
            button15.Location = new Point(47, 82);
            button15.Name = "button15";
            button15.Size = new Size(75, 23);
            button15.TabIndex = 4;
            button15.Text = "Save";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button15_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 56);
            label4.Name = "label4";
            label4.Size = new Size(32, 15);
            label4.TabIndex = 3;
            label4.Text = "Port:";
            // 
            // portBox
            // 
            portBox.Location = new Point(47, 53);
            portBox.Name = "portBox";
            portBox.Size = new Size(177, 23);
            portBox.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 27);
            label3.Name = "label3";
            label3.Size = new Size(20, 15);
            label3.TabIndex = 1;
            label3.Text = "IP:";
            // 
            // ipBox
            // 
            ipBox.Location = new Point(47, 24);
            ipBox.Name = "ipBox";
            ipBox.Size = new Size(177, 23);
            ipBox.TabIndex = 0;
            // 
            // statusLabel
            // 
            statusLabel.AutoSize = true;
            statusLabel.Location = new Point(230, 27);
            statusLabel.Name = "statusLabel";
            statusLabel.Size = new Size(42, 15);
            statusLabel.TabIndex = 5;
            statusLabel.Text = "Status:";
            // 
            // ConfigForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(groupBox1);
            Name = "ConfigForm";
            Size = new Size(338, 292);
            Load += ConfigForm_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button button15;
        private Label label4;
        private TextBox portBox;
        private Label label3;
        private TextBox ipBox;
        private Label statusLabel;
    }
}
