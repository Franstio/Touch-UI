﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestTCP1.Model;

namespace TestTCP1.Lib.DbUtil
{
    public abstract class DrawMarkPointUtil
    {
        public virtual  void DrawMark(PointF p,Color color, Image? img = null, PictureBox? frame = null)
        {
            if (img is null || frame is null)
                return;
            const float sizeDot = 0.05f;
            Image originalImage = img ;
            Graphics graph = Graphics.FromImage(originalImage);
            float factorX = (float)frame.Width / originalImage.Width;
            float factorY = (float)frame.Height / originalImage.Height;
            Pen pen = new Pen(color, frame.Width * sizeDot);
            graph.DrawEllipse(pen, new RectangleF(p.X / factorX, p.Y / factorY, frame.Width * sizeDot, frame.Height * sizeDot));
        }
    }
    public interface IMarkPointDb 
    {
        Task SaveMarkPoint(MarkPointModel model);
        Task RemoveMarkPoint(MarkPointModel model);
        Task ClearMarkPoint(string model);
        Task<IEnumerable<MarkPointModel>?> GetMarkPoint(string model);

        Task<IEnumerable<MarkPointModel>?> GetMarkPoint(string model,string area);
        void DrawMark(PointF p,Color color, Image? img = null, PictureBox? frame = null);

    }
}
